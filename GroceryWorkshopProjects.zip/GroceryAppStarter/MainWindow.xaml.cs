using System.Windows;

namespace GroceryApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void AddItem_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(ItemTextBox.Text))
            {
                GroceryList.Items.Add(ItemTextBox.Text);
                ItemTextBox.Clear();
            }
        }
    }
}
