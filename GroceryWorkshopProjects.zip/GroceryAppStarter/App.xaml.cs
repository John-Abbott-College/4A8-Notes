using System.Windows;

namespace GroceryApp
{
    public partial class App : Application
    {
    }
}
