using System;
using System.Linq;
using System.Windows;

namespace GroceryApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void AddItem_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(ItemTextBox.Text))
            {
                string item = ItemTextBox.Text;
                string qty = string.IsNullOrWhiteSpace(QuantityTextBox.Text) ? "1" : QuantityTextBox.Text;

                GroceryList.Items.Add($"{item} (x{qty})");

                ItemTextBox.Clear();
                QuantityTextBox.Clear();
            }
        }

        private void RemoveItem_Click(object sender, RoutedEventArgs e)
        {
            if (GroceryList.SelectedItem != null)
            {
                string item = GroceryList.SelectedItem.ToString();

                var result = MessageBox.Show(
                    $"Are you sure you want to remove '{item}'?",
                    "Confirm Delete",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning);

                if (result == MessageBoxResult.Yes)
                {
                    GroceryList.Items.Remove(item);
                }
            }
        }

        private void EmailList_Click(object sender, RoutedEventArgs e)
        {
            if (GroceryList.Items.Count == 0)
            {
                MessageBox.Show("Your list is empty!");
                return;
            }

            string body = string.Join("%0D%0A", GroceryList.Items.Cast<string>());
            string mailto = $"mailto:?subject=My Grocery List&body={body}";

            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(mailto)
            {
                UseShellExecute = true
            });
        }
    }
}
